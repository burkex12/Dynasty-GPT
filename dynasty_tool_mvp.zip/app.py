# Streamlit app main file

import streamlit as st
st.title('Dynasty Football Tool MVP')
